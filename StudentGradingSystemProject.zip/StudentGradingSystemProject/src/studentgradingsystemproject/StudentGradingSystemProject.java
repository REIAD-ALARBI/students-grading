package studentgradingsystemproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;


public class StudentGradingSystemProject {
    public static List students,departments,courses,attendance,grades;
    public static SimpleDateFormat fmt;
    
    public static void main(String[] args) {
        students = new ArrayList();
        departments = new ArrayList();
        courses = new ArrayList();
        attendance = new ArrayList();
        grades = new ArrayList();
        fmt = new SimpleDateFormat("dd/MM/yyyy");        
        
        
        create_students();
        create_department();
        create_course();
        create_attendance();
        create_grades();
        
        new Menu().setVisible(true);
        
        System.out.printf("\n");
    }
    
    public static void add_student(int std_id, String std_no, String std_name, 
                       String std_surname, char std_gender, 
                       String std_nationality, GregorianCalendar std_birthday) {
            Student st =new Student(std_id, std_no, std_name, std_surname,
                                    std_gender, std_nationality, std_birthday);
            students.add(st);
    }
    
    public static void edit_student(int std_id, String std_no, String std_name, 
                       String std_surname, char std_gender, 
                       String std_nationality, GregorianCalendar std_birthday) {
        
     Student st=null;
      Boolean found=false;
      Iterator <Student> itr = students.iterator();
      while (itr.hasNext()) {
          st = itr.next(); 
          if(std_id==st.getStd_id()) {
              found=true;
              break;
          }
      }
      if (found) {
          st.setStd_no(std_no);
          st.setStd_name(std_name);
          st.setStd_surname(std_surname);
          st.setStd_nationality(std_nationality);
          st.setStd_gender(std_gender);
          st.setStd_birthdate(std_birthday);
      }
    }
    
    
    public static void delete_student(int std_id) {
      Student st=null;
      Boolean found=false;
      Iterator <Student> itr = students.iterator();
      while (itr.hasNext()) {
          st = itr.next(); 
          if(std_id==st.getStd_id()) {
              found=true;
              break;
          }
      }
      if (found) students.remove(st);
      }

    public static void draw_line(int num) {
        String ln="";
        for (int i=0; i<num; i++) ln+="=";
        System.out.printf("\n"+ln);
    }
    
    public static void list_students() {
      Student st;
      //SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
      
      Iterator <Student> itr = students.iterator();
      System.out.printf("\n%10s %10s %15s %15s %10s %12s %12s",
              "Student Id", "Student No","Std. Name", "Std. Surname", 
              "Gender","Nationality", "Birthday");
        draw_line(90);
        
      while (itr.hasNext()) {
          st = itr.next(); 
          fmt.setCalendar(st.getStd_birthdate());
          System.out.printf("\n%10d %10s %15s %15s %10s %12s %12s",
              st.getStd_id(), st.getStd_no(), st.getStd_name(), 
              st.getStd_surname(), st.getStd_gender(), st.getStd_nationality(), 
              fmt.format(st.getStd_birthdate().getTime()));
      }
      draw_line(90);
        
    }
    
    
    public static void backup_student() throws IOException
    {
     File outfile  = new File("students.dat");
     FileOutputStream outfilestream = new FileOutputStream(outfile);
     ObjectOutputStream outObjectStream = new ObjectOutputStream(outfilestream);
     
     outObjectStream.writeObject(students);
     outObjectStream.close();
     
    }
    
    public static void retrieve_student() throws IOException, ClassNotFoundException
    {
     File infile  = new File("students.dat");
     FileInputStream infilestream = new FileInputStream(infile);
     ObjectInputStream inObjectStream = new ObjectInputStream(infilestream);
     students = (ArrayList)inObjectStream.readObject();
     
     inObjectStream.close();
     
    }
    
    public static GregorianCalendar strToGregorianCalendar(String stDate){
        GregorianCalendar bdate;
        
        bdate = new GregorianCalendar(
                Integer.parseInt(stDate.substring(6,10)),
                Integer.parseInt(stDate.substring(3,5))-1,
                Integer.parseInt(stDate.substring(0,2)));
        return bdate;       
    }
   
    
    public static void create_students() {
        
        System.out.printf("\n Add_student()\n\n");
        
        add_student(1,"189222", "Ayse","Cengiz",'F',"Turkey",
                    strToGregorianCalendar("28/03/2002"));
        add_student(2,"193342","Philip","Udoye",'M',"Nigeri",
                    strToGregorianCalendar("16/09/2003"));
        add_student(3,"189931","Kemal","Salih",'M',"TRNC",
                    strToGregorianCalendar("17/05/2002"));
        add_student(4,"188883","Fathima","Mohammad",'F',"Syria",
                    strToGregorianCalendar("22/11/2001"));                
        add_student(5,"189447","Jasmin","Faruq",'F',"Egypt",
                    strToGregorianCalendar("19/02/2002"));
        add_student(6,"189449","Mofida","Falleh",'F',"Libya",
                    strToGregorianCalendar("19/02/2002")); 
        add_student(7,"189247","AHmed","Fathi",'M',"Iran",
                    strToGregorianCalendar("19/02/2002")); 
        add_student(8,"189247","Tareq","Ahmed",'M',"Sudan",
                    strToGregorianCalendar("19/02/2002")); 
        add_student(9,"181447","Samia","Mahmud",'F',"Qatar",
                    strToGregorianCalendar("19/02/2002"));
        add_student(10,"189447","Murad","Basha",'M',"Turkey",
                    strToGregorianCalendar("19/02/2002")); 

        System.out.printf("\n List_student()\n\n");
        list_students();
    }
    public static void create_department() {
        System.out.printf("\n Tests for Class Department\n\n");
        System.out.printf("\n Add_department()\n\n");
        add_department(1, "IT");
        add_department(2, "Engineering");
        add_department(3, "medical");
        add_department(4, "pharmacy");
        add_department(5, "visual art");
        add_department(6, "Music");
        add_department(7, "History");
        add_department(8, "AAnimation");
        add_department(9, "Design");
        add_department(10, "Sports");
        add_department(11, "finance");
        add_department(12, "Accounting");
        add_department(13, "Banking");
        add_department(14, "Software Engineering");
        
        System.out.printf("\n List_department()\n\n");
        list_department();
    }
    
    public static void retrieve_department() throws IOException, ClassNotFoundException
    {
     File infile  = new File("departments.dat");
     FileInputStream infilestream = new FileInputStream(infile);
      try (ObjectInputStream inObjectStream = new ObjectInputStream(infilestream)) {
          departments = (ArrayList)inObjectStream.readObject();
      }
     
    }
    public static void backup_department() throws IOException
    {
     File outfile  = new File("departmets.dat");
     FileOutputStream outfilestream = new FileOutputStream(outfile);
      try (ObjectOutputStream outObjectStream = new ObjectOutputStream(outfilestream)) {
          outObjectStream.writeObject(departments);
      }
     
    }
    
    public static void add_department(int dep_id, String dep_name) {
            Department dp =new Department(dep_id, dep_name);
            departments.add(dp);
    }
    
      public static void edit_department(int dep_id, String dep_name) {
      Department dp=null;
      Boolean found=false;
      Iterator <Department> itr = departments.iterator();
      while (itr.hasNext()) {
          dp = itr.next(); 
          if(dep_id==dp.getDep_id()) {
              found=true;
              break;
          }
      }
      if (found) {
          dp.setDep_id(dep_id);
          dp.setDep_name(dep_name);

      }
      }

public static void delete_department(int dep_id) {
      Department dp=null;
      Boolean found=false;
      Iterator <Department> itr = departments.iterator();
      while (itr.hasNext()) {
          dp = itr.next(); 
          if(dep_id==(dp.getDep_id())) {
              found=true;
              break;
          }
      }
      if (found) departments.remove(dp);
      }
    
    public static void draw_line2(int num) {
        String ln="";
        for (int i=0; i<num; i++) ln+="=";
        System.out.printf("\n"+ln);
    }
    
    public static void list_department() {
      Department dp;
      Iterator <Department> itr = departments.iterator();
      System.out.printf("\n%2s %10s",
              "Id", "Department Name");
        draw_line(79);
        
      while (itr.hasNext()) {
          dp = itr.next(); 
          System.out.printf("\n%2d %10s", 
              dp.getDep_id(), dp.getDep_name());
      }
      draw_line(79);
        
} 
    public static void create_course() {
        System.out.printf("\n Tests for Class Course\n\n");
        System.out.printf("\n Add_course()\n\n");
        add_course(1,1,"Itec312","cloud computing");
        add_course(2,2,"Itec315","c language");
        add_course(3,3,"Itec412","database");
        add_course(4,4,"Itec112","java script");
        add_course(5,5,"Itec411","multimedia");
        add_course(6,6,"Itec113","ethical hacking");
        add_course(7,7,"Itec217","c++");
        add_course(8,8,"Itec119","Java");
        add_course(9,9,"Itec191","SQL");
        add_course(10,10,"Itec211","Python");
        add_course(11,11,"Itec141","Networks");
        add_course(12,12,"Itec181","Analysis");
        add_course(13,13,"Itec411","Network2");
        System.out.printf("\n List_course()\n\n");
        list_course();
    }
    
    public static void retrieve_course() throws IOException, ClassNotFoundException
    {
     File infile  = new File("course.dat");
     FileInputStream infilestream = new FileInputStream(infile);
      try (ObjectInputStream inObjectStream = new ObjectInputStream(infilestream)) {
          courses = (ArrayList)inObjectStream.readObject();
      }
     
    }
    public static void backup_course() throws IOException
    {
     File outfile  = new File("course.dat");
     FileOutputStream outfilestream = new FileOutputStream(outfile);
      try (ObjectOutputStream outObjectStream = new ObjectOutputStream(outfilestream)) {
          outObjectStream.writeObject(courses);
      }
     
    }
    
    public static void add_course(int crs_id, int dep_id, String crs_code, String crs_name) {
            Course cr =new Course(crs_id, dep_id, crs_code, crs_name);
            courses.add(cr);
    }
    
      public static void edit_course(int crs_id, int dep_id, String crs_code, String crs_name) {
      Course cr=null;
      Boolean found=false;
      Iterator <Course> itr = courses.iterator();
      while (itr.hasNext()) {
          cr = itr.next(); 
          if(crs_id==cr.getCrs_id()) {
              found=true;
              break;
          }
      }
      if (found) {
          cr.setCrs_id(crs_id);
          cr.setDep_id(dep_id);
          cr.setCrs_code(crs_code);
          cr.setCrs_name(crs_name);
      }
      }

public static void delete_course(int crs_id) {
      Course cr=null;
      Boolean found=false;
      Iterator <Course> itr = courses.iterator();
      while (itr.hasNext()) {
          cr = itr.next(); 
          if(crs_id==(cr.getCrs_id())) {
              found=true;
              break;
          }
      }
      if (found) courses.remove(cr);
      }
    
    public static void draw_line3(int num) {
        String ln="";
        for (int i=0; i<num; i++) ln+="=";
        System.out.printf("\n"+ln);
    }
    
    public static void list_course() {
      Course cr;
      Iterator <Course> itr = courses.iterator();
      System.out.printf("\n%2s %10s %15s %15s",
              "Course Id", "Department ID", "course code", "course name");
        draw_line(79);
        
      while (itr.hasNext()) {
          cr = itr.next();
          System.out.printf("\n%2d %10s %15s %15s", 
              cr.getCrs_id(), cr.getDep_id(), cr.getCrs_code(), cr.getCrs_name());
      }
      draw_line(79);
        
    }
    public static void create_attendance() {
        System.out.printf("\n Tests for Class Attendance\n\n");
        System.out.printf("\n Add_attendance()\n\n");
        add_attendance(1,1,2,strToGregorianCalendar("01/05/2022"));
        add_attendance(2,2,2,strToGregorianCalendar("02/05/2022"));
        add_attendance(3,3,2,strToGregorianCalendar("03/05/2022"));
        add_attendance(4,4,2,strToGregorianCalendar("04/05/2022"));
        add_attendance(5,5,2,strToGregorianCalendar("05/05/2022"));
        add_attendance(6,6,2,strToGregorianCalendar("23/05/2022"));
        add_attendance(7,7,7,strToGregorianCalendar("11/05/2022"));
        add_attendance(8,8,7,strToGregorianCalendar("12/05/2022"));
        add_attendance(9,9,7,strToGregorianCalendar("15/02/2022"));
        add_attendance(10,7,10,strToGregorianCalendar("01/05/2022"));
        add_attendance(11,7,11,strToGregorianCalendar("09/05/2022"));
        add_attendance(12,12,12,strToGregorianCalendar("08/05/2022"));
        add_attendance(13,12,13,strToGregorianCalendar("26/05/2022"));
        add_attendance(14,12,14,strToGregorianCalendar("29/05/2022"));

        
                
        System.out.printf("\n List_attendance()\n\n");
        list_attendance();
    }
    
    public static void retrieve_attendance() throws IOException, ClassNotFoundException
    {
     File infile  = new File("attendance.dat");
     FileInputStream infilestream = new FileInputStream(infile);
      try (ObjectInputStream inObjectStream = new ObjectInputStream(infilestream)) {
          attendance = (ArrayList)inObjectStream.readObject();
      }
     
    }
    public static void backup_attendance() throws IOException
    {
     File outfile  = new File("attendance.dat");
     FileOutputStream outfilestream = new FileOutputStream(outfile);
      try (ObjectOutputStream outObjectStream = new ObjectOutputStream(outfilestream)) {
          outObjectStream.writeObject(attendance);
      }
     
    }
    
    public static void add_attendance(int att_id, int std_id, int crs_id, GregorianCalendar att_date) {
            Attendance at =new Attendance(att_id, std_id, crs_id, att_date);
            attendance.add(at);
    }
    
      public static void edit_attendance(int att_id, int std_id, int crs_id, GregorianCalendar att_date) {
      Attendance at=null;
      Boolean found=false;
      Iterator <Attendance> itr = attendance.iterator();
      while (itr.hasNext()) {
          at = itr.next(); 
          if(att_id==at.getAtt_id()) {
              found=true;
              break;
          }
      }
      if (found) {
          at.setAtt_id(att_id);
          at.setStd_id(std_id);
          at.setCrs_id(crs_id);
          at.setAtt_date(att_date);
      }
      }

public static void delete_attendance(int att_id) {
      Attendance at=null;
      Boolean found=false;
      Iterator <Attendance> itr = attendance.iterator();
      while (itr.hasNext()) {
          at = itr.next(); 
          if(att_id==(at.getAtt_id())) {
              found=true;
              break;
          }
      }
      if (found) attendance.remove(at);
      }
    
    public static void draw_line5(int num) {
        String ln="";
        for (int i=0; i<num; i++) ln+="=";
        System.out.printf("\n"+ln);
    }
    
    public static void list_attendance() {
      Attendance at = null;
      Iterator <Attendance> itr = attendance.iterator();
      //fmt.setCalendar(at.getAtt_date());
      System.out.printf("\n%2s %10s %15s %15s",
              "Attendance Id", "Student ID", "course Id", "attandance date");
        draw_line(79);
        
      while (itr.hasNext()) {
          at = itr.next(); 
          System.out.printf("\n%2d %10s %15s %15s", 
              at.getAtt_id(), at.getStd_id(), at.getCrs_id(), fmt.format(at.getAtt_date().getTime()));
      }
      draw_line(79);
        
    }
    
    public static void create_grades() {
        System.out.printf("\n Tests for Class Grades\n\n");
        System.out.printf("\n Add_grades()\n\n");
        add_grades(1, 1, 1, 30, 25, 40, "B");
        add_grades(2, 2, 2, 20, 15, 40, "C");
        add_grades(3, 3, 3, 20, 25, 40, "C");
        add_grades(4, 4, 4, 25, 35, 40, "A");
        add_grades(5, 5, 5, 10, 25, 20, "D");
        add_grades(6, 5, 5, 10, 25, 20, "A");
        add_grades(7, 5, 5, 10, 25, 20, "B");
        add_grades(8, 5, 5, 10, 25, 20, "B");
        add_grades(9, 5, 5, 10, 25, 20, "B");
        add_grades(10, 5, 5, 10, 25, 20, "C");
        add_grades(11, 5, 5, 10, 25, 20, "A");
        add_grades(12, 5, 5, 10, 25, 20, "C");
        add_grades(13, 5, 5, 10, 25, 20, "F");
        add_grades(14, 5, 5, 10, 25, 20, "D");
        add_grades(15, 5, 5, 10, 25, 20, "B");
        
        System.out.printf("\n List_grades()\n\n");
        list_grades();
    }
    
    public static void retrieve_grades() throws IOException, ClassNotFoundException
    {
     File infile  = new File("grades.dat");
     FileInputStream infilestream = new FileInputStream(infile);
      try (ObjectInputStream inObjectStream = new ObjectInputStream(infilestream)) {
          grades = (ArrayList)inObjectStream.readObject();
      }
     
    }
    public static void backup_grades() throws IOException
    {
     File outfile  = new File("grades.dat");
     FileOutputStream outfilestream = new FileOutputStream(outfile);
      try (ObjectOutputStream outObjectStream = new ObjectOutputStream(outfilestream)) {
          outObjectStream.writeObject(grades);
      }
     
    }
    
    public static void add_grades(int grd_id, int std_id, int crs_id, float grd_mt,
           float grd_hw, float grd_final, String lgrade) {
            Grades gr =new Grades(grd_id, std_id, crs_id, grd_mt,
                                    grd_hw, grd_final, lgrade);
            grades.add(gr);
    }
    
      public static void edit_grades(int grd_id, int std_id, int crs_id, float grd_mt,
           float grd_hw, float grd_final, String lgrade) {
      Grades gr=null;
      Boolean found=false;
      Iterator <Grades> itr = grades.iterator();
      while (itr.hasNext()) {
          gr = itr.next(); 
          if(grd_id==gr.getGrd_id()) {
              found=true;
              break;
          }
      }
      if (found) {
          gr.setGrd_id(grd_id);
          gr.setStd_id(std_id);
          gr.setCrs_id(crs_id);
          gr.setGrd_mt(grd_mt);
          gr.setGrd_hw(grd_hw);
          gr.setGrd_final(grd_final);
          gr.setLgrade(lgrade);

      }
      }

public static void delete_grades(int grd_id) {
      Grades gr=null;
      Boolean found=false;
      Iterator <Grades> itr = grades.iterator();
      while (itr.hasNext()) {
          gr = itr.next(); 
          if(grd_id==(gr.getGrd_id())) {
              found=true;
              break;
          }
      }
      if (found) grades.remove(gr);
      }
    
    public static void draw_line4(int num) {
        String ln="";
        for (int i=0; i<num; i++) ln+="=";
        System.out.printf("\n"+ln);
    }
    
    public static void list_grades() {
      Grades gr;
      Iterator <Grades> itr = grades.iterator();
      System.out.printf("\n%2s %10s %15s %15s %10s %12s %12s",
              "Id", "Student id","course id", "mt grade ", 
              "hw grade","final grade", "letter grade");
        draw_line(79);
        
      while (itr.hasNext()) {
          gr = itr.next(); 
          System.out.printf("\n%2d %10s %15s %15s %10s %12s %12s", 
              gr.getGrd_id(), gr.getStd_id(), 
              gr.getCrs_id(), gr.getGrd_mt(),
              gr.getGrd_hw(), gr.getGrd_final(), gr.getLgrade());
      }
      draw_line(79);
        
    }

}


