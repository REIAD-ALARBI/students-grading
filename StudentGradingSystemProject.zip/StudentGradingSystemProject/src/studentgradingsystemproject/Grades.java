/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentgradingsystemproject;

import java.io.Serializable;

/**
 *
 * @author CL
 */
public class Grades implements Serializable{
    int grd_id;
    int std_id;
    int crs_id;
    float grd_mt;
    float grd_hw;
    float grd_final;
    String lgrade;

    public Grades(int grd_id, int std_id, int crs_id, float grd_mt, float grd_hw, float grd_final, String lgrade) {
        this.grd_id = grd_id;
        this.std_id = std_id;
        this.crs_id = crs_id;
        this.grd_mt = grd_mt;
        this.grd_hw = grd_hw;
        this.grd_final = grd_final;
        this.lgrade = lgrade;
    }

    public int getGrd_id() {
        return grd_id;
    }

    public void setGrd_id(int grd_id) {
        this.grd_id = grd_id;
    }

    public int getStd_id() {
        return std_id;
    }

    public void setStd_id(int std_id) {
        this.std_id = std_id;
    }

    public int getCrs_id() {
        return crs_id;
    }

    public void setCrs_id(int crs_id) {
        this.crs_id = crs_id;
    }

    public float getGrd_mt() {
        return grd_mt;
    }

    public void setGrd_mt(float grd_mt) {
        this.grd_mt = grd_mt;
    }

    public float getGrd_hw() {
        return grd_hw;
    }

    public void setGrd_hw(float grd_hw) {
        this.grd_hw = grd_hw;
    }

    public float getGrd_final() {
        return grd_final;
    }

    public void setGrd_final(float grd_final) {
        this.grd_final = grd_final;
    }

    public String getLgrade() {
        return lgrade;
    }

    public void setLgrade(String lgrade) {
        this.lgrade = lgrade;
    }
    
}
