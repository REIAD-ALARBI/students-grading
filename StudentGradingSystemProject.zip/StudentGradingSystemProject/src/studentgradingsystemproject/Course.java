/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentgradingsystemproject;

import java.io.Serializable;

/**
 *
 * @author CL
 */
public class Course implements Serializable {
    int crs_id;
    int dep_id;
    String crs_code;
    String crs_name;

    public Course(int crs_id, int dep_id, String crs_code, String crs_name) {
        this.crs_id = crs_id;
        this.dep_id = dep_id;
        this.crs_code = crs_code;
        this.crs_name = crs_name;
    }

    public int getCrs_id() {
        return crs_id;
    }

    public void setCrs_id(int crs_id) {
        this.crs_id = crs_id;
    }

    public int getDep_id() {
        return dep_id;
    }

    public void setDep_id(int dep_id) {
        this.dep_id = dep_id;
    }

    public String getCrs_code() {
        return crs_code;
    }

    public void setCrs_code(String crs_code) {
        this.crs_code = crs_code;
    }

    public String getCrs_name() {
        return crs_name;
    }

    public void setCrs_name(String crs_name) {
        this.crs_name = crs_name;
    }
    
}
